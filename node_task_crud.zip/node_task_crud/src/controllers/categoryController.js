// categoryController.js
const pool = require('../db');

// Create a new category
exports.createCategory = async (req, res) => {
          try {
            const { name, description } = req.body;
            const [result] = await pool.query('INSERT INTO categories (name, description) VALUES (?, ?)', [name, description]);
            res.status(201).json({ id: result.insertId, name, description });
          } catch (error) {
            console.error('Error creating category:', error);
            res.status(500).json({ error: 'Internal server error' });
          }
        };
        
        // Get a category by ID
        exports.getCategory = async (req, res) => {
          try {
            const categoryId = req.params.categoryId;
            const [rows] = await pool.query('SELECT * FROM categories WHERE id = ?', [categoryId]);
            if (rows.length === 0) {
              return res.status(404).json({ message: 'Category not found' });
            }
            res.status(200).json(rows[0]);
          } catch (error) {
            console.error('Error fetching category:', error);
            res.status(500).json({ error: 'Internal server error' });
          }
        };
        
        // Update a category by ID
        exports.updateCategory = async (req, res) => {
          try {
            const categoryId = req.params.categoryId;
            const { name, description } = req.body;
            await pool.query('UPDATE categories SET name = ?, description = ? WHERE id = ?', [name, description, categoryId]);
            res.status(200).json({ id: categoryId, name, description });
          } catch (error) {
            console.error('Error updating category:', error);
            res.status(500).json({ error: 'Internal server error' });
          }
        };
        
        // Delete a category by ID
        exports.deleteCategory = async (req, res) => {
          try {
            const categoryId = req.params.categoryId;
            await pool.query('DELETE FROM categories WHERE id = ?', [categoryId]);
            res.status(200).json({ message: 'Category deleted successfully' });
          } catch (error) {
            console.error('Error deleting category:', error);
            res.status(500).json({ error: 'Internal server error' });
          }
        };
