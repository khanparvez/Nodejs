// productController.js
const pool = require('../db');

exports.createProduct = async (req, res) => {
  try {
    const { name, description, price, categoryId } = req.body;
    const [result] = await pool.query('INSERT INTO products (name, description, price, category_id) VALUES (?, ?, ?, ?)', [name, description, price, categoryId]);
    res.status(201).json({ id: result.insertId, name, description, price, categoryId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getProduct = async (req, res) => {
  try {
    const productId = req.params.productId;
    const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [productId]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.status(200).json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateProduct = async (req, res) => {
  try {
    const productId = req.params.productId;
    const { name, description, price, categoryId } = req.body;
    await pool.query('UPDATE products SET name = ?, description = ?, price = ?, category_id = ? WHERE id = ?', [name, description, price, categoryId, productId]);
    res.status(200).json({ id: productId, name, description, price, categoryId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    const productId = req.params.productId;
    await pool.query('DELETE FROM products WHERE id = ?', [productId]);
    res.status(200).json({ message: 'Product deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
