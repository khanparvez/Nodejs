// authController.js
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('../db');
require('dotenv').config();

// authController.js


exports.signUp = async (req, res) => {
          try {
                    const { username, email, password } = req.body;

                    // Check if user with provided email already exists
                    const [existingUsers] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
                    if (existingUsers.length > 0) {
                              return res.status(400).json({ message: 'User with this email already exists' });
                    }

                    // Hash password
                    const hashedPassword = await bcrypt.hash(password, 10);

                    // Insert user into database
                    const [result] = await pool.query('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', [username, email, hashedPassword]);
                    const userId = result.insertId;


                    res.status(201).json({ message: 'User registered successfully' });
          } catch (error) {
                    console.error('Error signing up:', error);
                    res.status(500).json({ error: 'Internal server error' });
          }
};


exports.signIn = async (req, res) => {
          try {
                    const { email, password } = req.body;

                    // Check if user with provided email exists
                    const [existingUsers] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
                    if (existingUsers.length === 0) {
                              return res.status(401).json({ message: 'Invalid email or password' });
                    }

                    // Verify password
                    const user = existingUsers[0];
                    const validPassword = await bcrypt.compare(password, user.password);
                    if (!validPassword) {
                              return res.status(401).json({ message: 'Invalid email or password' });
                    }

                    // Create JWT token
                    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

                    // Store token in jwt_tokens table
                    await pool.query('INSERT INTO jwt_tokens (token, user_id) VALUES (?, ?)', [token, user.id]);

                    res.status(200).json({ message: 'Login successful', token });
          } catch (error) {
                    console.error('Error signing in:', error);
                    res.status(500).json({ error: 'Internal server error' });
          }
};

exports.logout = async (req, res) => {
          try {
                    const token = req.headers.authorization.split(' ')[1];
                    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);
                    const userId = decodedToken.userId;

                    // Remove token from token store
                    await pool.query('DELETE FROM jwt_tokens WHERE token = ? AND user_id = ?', [token, userId]);

                    res.status(200).json({ message: 'Logout successful' });
          } catch (error) {
                    console.error('Error logging out:', error);
                    res.status(500).json({ error: 'Internal server error' });
          }
};
