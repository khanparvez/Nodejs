// index.js
const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const authRoutes = require('../src/routes/authRoutes');
const categoryRoutes = require('../src/routes/categoryRoutes');
const productRoutes = require('../src/routes/productRoutes');
const jwt = require('jsonwebtoken'); // Add this line to import jsonwebtoken module


dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());

// Authentication middleware
app.use((req, res, next) => {
          // Exclude signup and signin routes from authentication
          if (req.path === '/auth/signup' || req.path === '/auth/signin') {
            return next();
          }
        
          // Check if Authorization header is present
          const authHeader = req.headers['authorization'];
          if (!authHeader) {
            return res.status(401).json({ message: 'Authorization header is missing' });
          }
        
          // Check if token starts with 'Bearer'
          const token = authHeader.split(' ')[1];
          if (!token) {
            return res.status(401).json({ message: 'Bearer token is missing' });
          }
        
          // Verify JWT token
          jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
            if (err) {
              return res.status(401).json({ message: 'Invalid token' });
            }
            req.userId = decoded.userId;
            next();
          });
        });



// Routes
app.use('/auth', authRoutes);
app.use('/categories', categoryRoutes);
app.use('/products', productRoutes);

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
